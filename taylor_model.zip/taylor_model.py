
# CST-305: Principles of Modeling and Simulation Lecture & Lab
# Aime Serge Tuyishime
# Ricardo Citro
# April 6, 2025
# Project Overview:
# This project applies to Taylor series and differential equations
# to solve and approximate solutions of second-order linear and nonlinear
# models. It includes analytical expansion of given differential equations
# and models system performance using a holistic mathematical approach. The
# work demonstrates practical applications in computing, emphasizing
# performance evaluation, cost-efficiency, and responsible system design,
# while considering legal, ethical, and professional standards in the field
# of computer modeling and simulation.

# Taylor Series Approximation Plot for the Differential Equation:
# y''' - 2xy' + x^2y = 0
# Approximation centered at x = 0, evaluated up to degree 4

import numpy as np
import matplotlib.pyplot as plt

# Define the Taylor series coefficients (up to x^4)
# y(0) = 1, y'(0) = -1, y''(0) = 0, y'''(0) = -2, y''''(0) = -2
# Coefficients are based on Taylor series: a_n = y^n(0)/n!
coeffs = [1, -1, 0, -1/3, -1/12]

# Define the Taylor polynomial function
def taylor_poly(x):
    return sum(coeff * x**n for n, coeff in enumerate(coeffs))

# Generate x values in the interval [-2, 5]
x_vals = np.linspace(-2, 5, 400)

# Evaluate the Taylor polynomial at each x
y_vals = [taylor_poly(x) for x in x_vals]

# Create the plot
plt.figure(figsize=(10, 6))
plt.plot(x_vals, y_vals, label='Taylor Polynomial (up to $x^4$)', color='blue')

# Highlight the evaluated point at x = 3.5
plt.scatter(3.5, -29.2968, color='red', label=r'$y(3.5) \approx -29.2968$')

# Set plot title and labels
plt.title('Taylor Approximation for $y\'\' - 2xy\' + x^2y = 0$')
plt.xlabel('$x$')
plt.ylabel('$y(x)$')
plt.legend()
plt.grid(True)

# Show the plot
plt.show()
