# System Performance Modeling Using Taylor Series

## Project Overview
 This project models and evaluates computer
 system performance using second-order differential 
 equations and Taylor series. It focuses on 
 approximating performance based on system resources 
 (CPU, memory, storage) and task complexity.

## Features
- Differential equation modeling
- Taylor series expansion
- Python-based implementation
- Graphical visualization using matplotlib

## How to Run
1. Make sure Python 3.x is installed.
2. Install dependencies:
```bash
pip install numpy matplotlib
3.	Run the Python script:
python taylor_model.py
Author
Aime Serge Tuyishime
